package DEL_PIN.Leg_50429.EJ1;

public class Donante implements Runnable{

    CentroHemoterapia centroHemoterapia;

    public Donante (CentroHemoterapia _centro) {

        this.centroHemoterapia = _centro;
    }

    @Override
    public void run() {
        String nombre = Thread.currentThread().getName();
        
        this.centroHemoterapia.pedirTurno(nombre);
        
        if (this.centroHemoterapia.admisionDonante(nombre)) {
            this.centroHemoterapia.entrevistaDonante(nombre);
            this.centroHemoterapia.extraccionDonante(nombre);
            this.centroHemoterapia.entregaCertificado(nombre);
        }
    }    
}